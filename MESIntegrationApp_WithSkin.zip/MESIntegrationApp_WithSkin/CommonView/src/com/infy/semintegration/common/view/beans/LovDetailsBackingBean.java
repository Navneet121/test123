package com.infy.semintegration.common.view.beans;

import com.infy.semintegration.common.view.utils.ADFUtils;

import javax.faces.context.FacesContext;

import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.adf.share.ADFContext;

import oracle.adf.view.rich.component.rich.RichPopup;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.output.RichOutputText;

import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.AttributeBinding;
import oracle.binding.BindingContainer;
import oracle.binding.OperationBinding;

import oracle.jbo.ViewCriteria;
import oracle.jbo.server.ViewObjectImpl;

import org.apache.myfaces.trinidad.event.SelectionEvent;

public class LovDetailsBackingBean {
    private RichOutputText outputtextBinding;
    private RichPopup detailsPopupBinding;
    private static boolean flag=false;
    private RichInputText setupCodeBinding;
    private RichInputText setupNameBinding;

    public LovDetailsBackingBean() {
        Object passSetupCode= FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("passSetupCode");
       
    System.out.println("passSetupCode:"+passSetupCode);
        if((!passSetupCode.equals("")) &&(passSetupCode!=null)&&flag==false)
        {
//        BindingContext ctx1 = BindingContext.getCurrent();      
//        DCBindingContainer bc1 = (DCBindingContainer) ctx1.getCurrentBindingsEntry();
//        DCIteratorBinding iterator = bc1.findIteratorBinding("SetupDetailsView1Iterator");
//        ViewObjectImpl vo =(ViewObjectImpl)iterator.getViewObject();
//        ViewCriteria vc =vo.getViewCriteria("SetupDetailsViewCriteria");
//        vo.applyViewCriteria(vc);
//        vo.setNamedWhereClauseParam("bindSetupCode",null);
//        vo.executeQuery();
//        vo.setNamedWhereClauseParam("bindSetupCode",passSetupCode);
//        vo.executeQuery();
        }
    }

    public void setOutputtextBinding(RichOutputText outputtextBinding) {
        this.outputtextBinding = outputtextBinding;
    }

    public RichOutputText getOutputtextBinding() {
        return outputtextBinding;
    }

    public void createDetails(ActionEvent actionEvent) {
        flag=true;
        DCBindingContainer bindings =
            (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding operationBinding = 
             bindings.getOperationBinding("CreateInsert");
        
       
        
        operationBinding.execute();
    oracle.jbo.Row detailsRow = ADFUtils.findIterator("SetupDetailsView1Iterator").getCurrentRow();
    
    detailsRow.setAttribute("SetupCode", FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("passSetupCode"));
    detailsRow.setAttribute("SetupName", FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("passSetupName"));
    setupCodeBinding.setDisabled(true);
    setupNameBinding.setDisabled(true);
    AdfFacesContext.getCurrentInstance().addPartialTarget(setupCodeBinding);
    AdfFacesContext.getCurrentInstance().addPartialTarget(setupNameBinding);
    RichPopup.PopupHints hints = new RichPopup.PopupHints();
    getDetailsPopupBinding().show(hints);
}

    public void setDetailsPopupBinding(RichPopup detailsPopupBinding) {
        this.detailsPopupBinding = detailsPopupBinding;
    }

    public RichPopup getDetailsPopupBinding() {
        return detailsPopupBinding;
    }

    public void saveDetails(ActionEvent actionEvent) {
        DCBindingContainer bindings =
            (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding operationBinding = 
             bindings.getOperationBinding("Commit");
        operationBinding.execute();
        
        detailsPopupBinding.hide();
        
        BindingContext ctx1 = BindingContext.getCurrent();      
        DCBindingContainer bc1 = (DCBindingContainer) ctx1.getCurrentBindingsEntry();
        DCIteratorBinding iterator = bc1.findIteratorBinding("SetupDetailsView1Iterator");
        ViewObjectImpl vo =(ViewObjectImpl)iterator.getViewObject();
        ViewCriteria vc =vo.getViewCriteria("SetupDetailsViewCriteria1");
        vo.applyViewCriteria(vc);
        vo.setNamedWhereClauseParam("bindSetupId",null);
        vo.executeQuery();
        iterator();
       // iterator();
    }

    public void cancelDetails(ActionEvent actionEvent) {
        DCBindingContainer bindings =
            (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding operationBinding = 
             bindings.getOperationBinding("Rollback");
        operationBinding.execute();
       
        BindingContext ctx1 = BindingContext.getCurrent();      
        DCBindingContainer bc1 = (DCBindingContainer) ctx1.getCurrentBindingsEntry();
        DCIteratorBinding iterator = bc1.findIteratorBinding("SetupDetailsView1Iterator");
        ViewObjectImpl vo =(ViewObjectImpl)iterator.getViewObject();
        ViewCriteria vc =vo.getViewCriteria("SetupDetailsViewCriteria1");
        vo.applyViewCriteria(vc);
        vo.setNamedWhereClauseParam("bindSetupId",null);
        vo.executeQuery();
        System.out.println("SetupDetailsView1Iterator cancelDetails"+vo.getEstimatedRowCount());
        iterator();
        detailsPopupBinding.hide();
      //  iterator();
    }
    
    public void iterator(){
        BindingContext ctx1 = BindingContext.getCurrent();      
        DCBindingContainer bc1 = (DCBindingContainer) ctx1.getCurrentBindingsEntry();
        DCIteratorBinding iterator = bc1.findIteratorBinding("SetupDetailsView1Iterator");
        ViewObjectImpl vo =(ViewObjectImpl)iterator.getViewObject();
        ViewCriteria vc =vo.getViewCriteria("SetupDetailsViewCriteria");
        vo.applyViewCriteria(vc);
        vo.setNamedWhereClauseParam("bindSetupCode",null);
        vo.executeQuery();
        System.out.println("When Pass Null"+vo.getEstimatedRowCount());
        vo.setNamedWhereClauseParam("bindSetupCode",FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("passSetupCode"));
        vo.executeQuery();
        System.out.println("When Pass Value"+vo.getEstimatedRowCount());
    }

    public void editDetails(ActionEvent actionEvent) {
        flag=true;
        //oracle.jbo.Row detailsRow = ADFUtils.findIterator("SetupDetailsView1Iterator").getCurrentRow();
        //Object setupId=detailsRow.getAttribute("SetupId");
        
        // Get the data from an ADF tree or table
      /* DCBindingContainer dcBindings = (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();

        // Get a attribute value of the current row of iterator
        DCIteratorBinding iterBind= (DCIteratorBinding)dcBindings.get("SetupDetailsView1Iterator");
        Object setupId = iterBind.getCurrentRow().getAttribute("SetupId");
      
        System.out.println("setupId:"+setupId);
        
        BindingContext ctx1 = BindingContext.getCurrent();      
        DCBindingContainer bc1 = (DCBindingContainer) ctx1.getCurrentBindingsEntry();
        DCIteratorBinding iterator = bc1.findIteratorBinding("SetupDetailsView1Iterator");
        ViewObjectImpl vo =(ViewObjectImpl)iterator.getViewObject();
        ViewCriteria vc =vo.getViewCriteria("SetupDetailsViewCriteria1");
        vo.applyViewCriteria(vc);
        vo.setNamedWhereClauseParam("bindSetupId",null);
        vo.executeQuery();
        vo.setNamedWhereClauseParam("bindSetupId",setupId);
        vo.executeQuery();*/
        
        RichPopup.PopupHints hints = new RichPopup.PopupHints();
        getDetailsPopupBinding().show(hints);
    }

    public void backToSearch(ActionEvent actionEvent) {
        flag=false;
    }

    public void setSetupCodeBinding(RichInputText setupCodeBinding) {
        this.setupCodeBinding = setupCodeBinding;
    }

    public RichInputText getSetupCodeBinding() {
        return setupCodeBinding;
    }

    public void setSetupNameBinding(RichInputText setupNameBinding) {
        this.setupNameBinding = setupNameBinding;
    }

    public RichInputText getSetupNameBinding() {
        return setupNameBinding;
    }


    public void deleteDetails(ActionEvent actionEvent) {
        DCBindingContainer bindings =
            (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
        OperationBinding operationBinding = 
             bindings.getOperationBinding("Delete");
        operationBinding.execute();
        
       
        OperationBinding deleteOperationBinding = 
             bindings.getOperationBinding("Commit");
        deleteOperationBinding.execute();
    }
}
