package com.infy.semintegration.common.view.beans;

import com.infy.semintegration.common.view.utils.ADFUtils;
import com.infy.semintegration.common.view.utils.JSFUtils;

import javax.el.ELContext;
import javax.el.ExpressionFactory;
import javax.el.MethodExpression;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.view.rich.component.rich.input.RichInputText;
import oracle.adf.view.rich.component.rich.input.RichSelectOneChoice;
import oracle.adf.view.rich.component.rich.nav.RichCommandLink;
import oracle.adf.view.rich.component.rich.output.RichOutputText;

import oracle.jbo.ViewCriteria;
import oracle.jbo.server.ViewObjectImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import oracle.adf.controller.binding.BindingUtils;
import oracle.adf.model.binding.DCIteratorBinding;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.binding.OperationBinding;

import oracle.jbo.Row;
import oracle.jbo.RowIterator;
import oracle.jbo.RowSetIterator;
import oracle.jbo.ViewObject;
import oracle.jbo.domain.Date;
import oracle.jbo.domain.Number;


public class TimeCardBackingBean {
    private RichCommandLink bndTimeCardId;
    private RichOutputText bndTotalAmount;
    private RichOutputText bndLabourAmount;
    private RichOutputText bndMaterialAmount;
    private String poId;
    private String rateCardId;
    private RichOutputText bndApprover;
    private RichOutputText bndPOAmount;
    private RichInputText bndRoleType;
    private RichInputText bndRole;
    private RichInputText bndRegion;
    private RichInputText bndWorkType;
    private RichSelectOneChoice bndRoleType1;
    private RichSelectOneChoice bndRateCardId;
    private RichSelectOneChoice bndRole1;
    private RichSelectOneChoice bndRegion1;
    private RichSelectOneChoice bndWorkType1;
    private static int lineNumCounter;
    private RichInputText bndLineNumber;


    public TimeCardBackingBean() {
    }

    public void searchForTimeCards(ActionEvent actionEvent) {

        OperationBinding op = ADFUtils.findOperation("SearchTimeCards");
        Map paramsMap = op.getParamsMap();

        Date weekEndDate = (Date) ADFUtils.getBoundAttributeValue("WeekEndingDate1");

        paramsMap.put("bPoLineId", ADFUtils.getBoundAttributeValue("PoLineId2"));

        paramsMap.put("bPoHeaderId", ADFUtils.getBoundAttributeValue("PoHeaderId2"));

        if (weekEndDate != null) {
            paramsMap.put("bWeekendDate", weekEndDate);
        }

        paramsMap.put("bTimeCardNo", ADFUtils.getBoundAttributeValue("TimeCardNumber1"));

        op.execute();
    }

    public void poSelectionListener(ValueChangeEvent valueChangeEvent) {
        valueChangeEvent.getComponent().processUpdates(FacesContext.getCurrentInstance());
        OperationBinding op = ADFUtils.findOperation("FetchPoLineList");
        op.getParamsMap().put("bPoHeaderId", ADFUtils.getBoundAttributeValue("PoHeaderId2"));
        op.execute();
    }

    public void submitTimeCard(ActionEvent actionEvent) {

        RowSetIterator timeCardLineRSI = ADFUtils.findIterator("TimeCardLineIterator").getRowSetIterator();

        Row timeCardLineRow = timeCardLineRSI.first();

        boolean doSubmit;
        boolean statusFlag = false;
        int totalLabourAmount = 0;
        int totalMaterialAmount = 0;
        int totalOtherExpAmt = 0;
        List<oracle.jbo.domain.Number> lineIdList = new ArrayList<oracle.jbo.domain.Number>();


        BindingContext ctx1 = BindingContext.getCurrent();
        DCBindingContainer bc1 = (DCBindingContainer) ctx1.getCurrentBindingsEntry();
        DCIteratorBinding iterator1 = bc1.findIteratorBinding("TimeCardHeaderIterator");
        Row TimeCardHeaderRow = iterator1.getCurrentRow();
        oracle.jbo.domain.Number PoHeaderId = (oracle.jbo.domain.Number) TimeCardHeaderRow.getAttribute("PoHeaderId");
        System.out.println("PoHeaderId IN submitTimeCard...." + PoHeaderId);


        DCIteratorBinding iterator = bc1.findIteratorBinding("POHeaderViewIterator");
        ViewObjectImpl vo = (ViewObjectImpl) iterator.getViewObject();
        ViewCriteria vc = vo.getViewCriteria("POHeaderViewCriteria");
        vo.applyViewCriteria(vc);
        vo.setNamedWhereClauseParam("bPoHId", PoHeaderId);
        vo.executeQuery();
        Row poHeaderRow = iterator.getCurrentRow();
        oracle.jbo.domain.Number poAmountRemaining = (oracle.jbo.domain.Number) poHeaderRow.getAttribute("AmountLimit");

        System.out.println("poAmountRemaining..." + poAmountRemaining);


        while (timeCardLineRow != null) {
            doSubmit = false;

            oracle.jbo.domain.Number PoLineId = (oracle.jbo.domain.Number) timeCardLineRow.getAttribute("PoLineId");
            System.out.println("PoLineId..." + PoLineId);
            String status = (String) timeCardLineRow.getAttribute("Status");
            String selectedFlag = (String) timeCardLineRow.getAttribute("SelectedFlag");
            String type = (String) timeCardLineRow.getAttribute("EntryType");

            if (status.equalsIgnoreCase("DRAFT") && selectedFlag != null && selectedFlag.equalsIgnoreCase("Y")) {

                RowIterator labourChargesRI = (RowIterator) timeCardLineRow.getAttribute("LaborChargesView");

                Row labourChargesRow = labourChargesRI.first();
                while (labourChargesRow != null) {

                    OperationBinding fetchRates = ADFUtils.findOperation("FetchRates");
                    Map paramsMap = fetchRates.getParamsMap();
                    paramsMap.put("bWeekendDate", ADFUtils.getBoundAttributeValue("WeekEnd"));
                    paramsMap.put("bPoHeaderId", ADFUtils.getBoundAttributeValue("PoHeaderId1"));
                    paramsMap.put("bSupplierId", ADFUtils.getBoundAttributeValue("SupplierId"));
                    paramsMap.put("bSupplierSiteId", ADFUtils.getBoundAttributeValue("SupplierSiteId"));
                    paramsMap.put("bRateType", labourChargesRow.getAttribute("RateType"));
                    paramsMap.put("bRegion", labourChargesRow.getAttribute("Region"));
                    paramsMap.put("bRoleType", labourChargesRow.getAttribute("RoleType"));
                    paramsMap.put("bWorkType", labourChargesRow.getAttribute("WorkType"));
                    paramsMap.put("bRole", labourChargesRow.getAttribute("Role"));

                    fetchRates.execute();

                    Row ratesRow = ADFUtils.findIterator("RatesForTimeCardsIterator").getCurrentRow();
                    if (ratesRow == null) {
                        paramsMap.put("bPoHeaderId", null);
                        fetchRates.execute();
                        ratesRow = ADFUtils.findIterator("RatesForTimeCardsIterator").getCurrentRow();
                        if (ratesRow == null) {
                            JSFUtils.addFacesErrorMessage("Matching Rates not defined for one or more labor charge entries");
                            return;
                        }
                    }
                    oracle.jbo.domain.Number rate = (oracle.jbo.domain.Number) ratesRow.getAttribute("Rate");

                    oracle.jbo.domain.Number workHours =
                        (oracle.jbo.domain.Number) labourChargesRow.getAttribute("WeekHours");

                    if (type.equalsIgnoreCase("Daily")) {
                        oracle.jbo.domain.Number day1Hours =
                            (oracle.jbo.domain.Number) labourChargesRow.getAttribute("Day1Hours");
                        oracle.jbo.domain.Number day2Hours =
                            (oracle.jbo.domain.Number) labourChargesRow.getAttribute("Day2Hours");
                        oracle.jbo.domain.Number day3Hours =
                            (oracle.jbo.domain.Number) labourChargesRow.getAttribute("Day3Hours");
                        oracle.jbo.domain.Number day4Hours =
                            (oracle.jbo.domain.Number) labourChargesRow.getAttribute("Day4Hours");
                        oracle.jbo.domain.Number day5Hours =
                            (oracle.jbo.domain.Number) labourChargesRow.getAttribute("Day5Hours");
                        oracle.jbo.domain.Number day6Hours =
                            (oracle.jbo.domain.Number) labourChargesRow.getAttribute("Day6Hours");
                        oracle.jbo.domain.Number day7Hours =
                            (oracle.jbo.domain.Number) labourChargesRow.getAttribute("Day7Hours");

                        workHours =
                            (day1Hours == null ? new oracle.jbo.domain.Number(0) : day1Hours).add(day2Hours == null ?
                                                                                                  new oracle.jbo.domain.Number(0) :
                                                                                                  day2Hours).add(day3Hours ==
                                                                                                                 null ?
                                                                                                                 new oracle.jbo.domain.Number(0) :
                                                                                                                 day3Hours).add(day4Hours ==
                                                                                                                                null ?
                                                                                                                                new oracle.jbo.domain.Number(0) :
                                                                                                                                day4Hours).add(day5Hours ==
                                                                                                                                               null ?
                                                                                                                                               new oracle.jbo.domain.Number(0) :
                                                                                                                                               day5Hours).add(day6Hours ==
                                                                                                                                                              null ?
                                                                                                                                                              new oracle.jbo.domain.Number(0) :
                                                                                                                                                              day6Hours).add(day7Hours ==
                                                                                                                                                                             null ?
                                                                                                                                                                             new oracle.jbo.domain.Number(0) :
                                                                                                                                                                             day7Hours);
                    }

                    labourChargesRow.setAttribute("Rate", rate);
                    labourChargesRow.setAttribute("Amount",
                                                  (rate == null ? new oracle.jbo.domain.Number(0) :
                                                   rate).multiply(workHours));
                    AdfFacesContext.getCurrentInstance().addPartialTarget(getBndLabourAmount());
                    totalLabourAmount =
                        totalLabourAmount + (Integer.valueOf(labourChargesRow.getAttribute("Amount").toString()));
                    labourChargesRow = labourChargesRI.next();
                }

                RowIterator materialChargesRI = (RowIterator) timeCardLineRow.getAttribute("MaterialChargesView");
                Row materialChargesRow = materialChargesRI.first();
                while (materialChargesRow != null) {
                    oracle.jbo.domain.Number price =
                        (oracle.jbo.domain.Number) materialChargesRow.getAttribute("Price");

                    oracle.jbo.domain.Number quantity =
                        (oracle.jbo.domain.Number) materialChargesRow.getAttribute("Quantity");
                    materialChargesRow.setAttribute("Amount",
                                                    (price == null ? new oracle.jbo.domain.Number(0) :
                                                     price).multiply(quantity));
                    AdfFacesContext.getCurrentInstance().addPartialTarget(getBndMaterialAmount());
                    totalMaterialAmount =
                        totalMaterialAmount + Integer.valueOf(materialChargesRow.getAttribute("Amount").toString());
                    materialChargesRow = materialChargesRI.next();
                }
                RowIterator OtherExpensesRI = (RowIterator) timeCardLineRow.getAttribute("OtherExpensesView");
                Row otherChargesRow = OtherExpensesRI.first();
                while (otherChargesRow != null) {
                    int amount = Integer.valueOf(otherChargesRow.getAttribute("Amount").toString());
                    totalOtherExpAmt = totalOtherExpAmt + amount;
                    otherChargesRow = OtherExpensesRI.next();
                }
                if (labourChargesRI.getFetchedRowCount() > 0 || materialChargesRI.getFetchedRowCount() > 0 ||
                    OtherExpensesRI.getFetchedRowCount() > 0) {
                    doSubmit = true;
                }

                try {
                    if (doSubmit) {

                        if (poAmountRemaining.equals(null)) {
                            System.out.println("inside status check for null value");
                            statusFlag = true;
                            timeCardLineRow.setAttribute("Status", "SUBMITTED");
                            timeCardLineRow.setAttribute("SelectedFlag", "N");
                        }
                        oracle.jbo.domain.Number timeCardLineId =
                            (oracle.jbo.domain.Number) timeCardLineRow.getAttribute("TimeCardLineId");

                        lineIdList.add(timeCardLineId);
                        //     Case 1 Only Labour is having row details
                        if (0 != totalLabourAmount && 0 == totalMaterialAmount && 0 == totalOtherExpAmt) {
                            timeCardLineRow.setAttribute("TotalAmount", totalLabourAmount);
                            if (poAmountRemaining.compareTo(totalLabourAmount) == 1 ||
                                poAmountRemaining.compareTo(totalLabourAmount) == 0) {
                                oracle.jbo.domain.Number FinalWoAmount =
                                    (oracle.jbo.domain.Number) poAmountRemaining.minus(totalLabourAmount);
                                System.out.println("FinalWoAmount..." + FinalWoAmount);
                                poHeaderRow.setAttribute("AmountLimit", FinalWoAmount);
                                getBndPOAmount().setValue(FinalWoAmount);
                                statusFlag = true;
                            } else {
                                JSFUtils.addFacesErrorMessage("Insufficient remaining Amount");
                            }
                        }
                        //     Case 2 Only Material is having row details
                        else if (0 == totalLabourAmount && 0 != totalMaterialAmount && 0 == totalOtherExpAmt) {
                            timeCardLineRow.setAttribute("TotalAmount", totalMaterialAmount);
                            if (poAmountRemaining.compareTo(totalMaterialAmount) == 1 ||
                                poAmountRemaining.compareTo(totalMaterialAmount) == 0) {
                                oracle.jbo.domain.Number FinalWoAmount =
                                    (oracle.jbo.domain.Number) poAmountRemaining.minus(totalMaterialAmount);
                                System.out.println("FinalWoAmount..." + FinalWoAmount);
                                poHeaderRow.setAttribute("AmountLimit", FinalWoAmount);
                                getBndPOAmount().setValue(FinalWoAmount);
                                statusFlag = true;
                            } else {
                                JSFUtils.addFacesErrorMessage("Insufficient remaining Amount");
                            }
                        }
                        //     Case 3 Only other Expenses is having row details
                        else if (0 == totalLabourAmount && 0 == totalMaterialAmount && 0 != totalOtherExpAmt) {
                            timeCardLineRow.setAttribute("TotalAmount", totalOtherExpAmt);
                            if (poAmountRemaining.compareTo(totalOtherExpAmt) == 1 ||
                                poAmountRemaining.compareTo(totalOtherExpAmt) == 0) {
                                oracle.jbo.domain.Number FinalWoAmount =
                                    (oracle.jbo.domain.Number) poAmountRemaining.minus(totalOtherExpAmt);
                                System.out.println("FinalWoAmount..." + FinalWoAmount);
                                poHeaderRow.setAttribute("AmountLimit", FinalWoAmount);
                                getBndPOAmount().setValue(FinalWoAmount);
                                statusFlag = true;
                            } else {
                                JSFUtils.addFacesErrorMessage("Insufficient remaining Amount");
                            }
                        }
                        // Case 4 All tabs having row details
                        else if (0 != totalMaterialAmount && 0 != totalLabourAmount) {
                            int totalLMAmount = totalLabourAmount + totalMaterialAmount;
                            timeCardLineRow.setAttribute("TotalAmount", totalLMAmount);
                            if (poAmountRemaining.compareTo(totalLMAmount) == 1 ||
                                poAmountRemaining.compareTo(totalLMAmount) == 0) {
                                oracle.jbo.domain.Number FinalWoAmount =
                                    (oracle.jbo.domain.Number) poAmountRemaining.minus(totalLMAmount);
                                System.out.println("FinalWoAmount..." + FinalWoAmount);
                                poHeaderRow.setAttribute("AmountLimit", FinalWoAmount);
                                getBndPOAmount().setValue(FinalWoAmount);
                                statusFlag = true;
                            } else {
                                JSFUtils.addFacesErrorMessage("Insufficient remaining Amount");
                            }
                            if (0 != totalOtherExpAmt) {
                                timeCardLineRow.setAttribute("TotalAmount", totalLMAmount + totalOtherExpAmt);
                                if (poAmountRemaining.compareTo(totalLMAmount + totalOtherExpAmt) == 1 ||
                                    poAmountRemaining.compareTo(totalLMAmount + totalOtherExpAmt) == 0) {
                                    oracle.jbo.domain.Number FinalWoAmount =
                                        (oracle.jbo.domain.Number) poAmountRemaining.minus(totalLMAmount +
                                                                                           totalOtherExpAmt);
                                    System.out.println("FinalWoAmount..." + FinalWoAmount);
                                    poHeaderRow.setAttribute("AmountLimit", FinalWoAmount);
                                    getBndPOAmount().setValue(FinalWoAmount);
                                    statusFlag = true;
                                } else {
                                    JSFUtils.addFacesErrorMessage("Insufficient remaining Amount");
                                }
                            }
                        }
                        // Case 5 Labour and Material having row details
                        else if (0 != totalLabourAmount && 0 != totalMaterialAmount && 0 == totalOtherExpAmt) {
                            int totalLMAmount = totalLabourAmount + totalMaterialAmount;
                            timeCardLineRow.setAttribute("TotalAmount", totalLMAmount);
                            if (poAmountRemaining.compareTo(totalLMAmount) == 1 ||
                                poAmountRemaining.compareTo(totalLMAmount) == 0) {
                                oracle.jbo.domain.Number FinalWoAmount =
                                    (oracle.jbo.domain.Number) poAmountRemaining.minus(totalLMAmount);
                                System.out.println("FinalWoAmount..." + FinalWoAmount);
                                poHeaderRow.setAttribute("AmountLimit", FinalWoAmount);
                                getBndPOAmount().setValue(FinalWoAmount);
                                statusFlag = true;
                            } else {
                                JSFUtils.addFacesErrorMessage("Insufficient remaining Amount");
                            }
                        }
                        // Case 6 Labour and Other having row details
                        else if (0 != totalLabourAmount && 0 == totalMaterialAmount && 0 != totalOtherExpAmt) {
                            int totalLOAmount = totalLabourAmount + totalOtherExpAmt;
                            timeCardLineRow.setAttribute("TotalAmount", totalLOAmount);
                            if (poAmountRemaining.compareTo(totalLOAmount) == 1 ||
                                poAmountRemaining.compareTo(totalLOAmount) == 0) {
                                oracle.jbo.domain.Number FinalWoAmount =
                                    (oracle.jbo.domain.Number) poAmountRemaining.minus(totalLOAmount);
                                System.out.println("FinalWoAmount..." + FinalWoAmount);
                                poHeaderRow.setAttribute("AmountLimit", FinalWoAmount);
                                getBndPOAmount().setValue(FinalWoAmount);
                                statusFlag = true;
                            } else {
                                JSFUtils.addFacesErrorMessage("Insufficient remaining Amount");
                            }
                        }
                        // Case 7 Material and Other having row details
                        else if (0 == totalLabourAmount && 0 != totalMaterialAmount && 0 != totalOtherExpAmt) {
                            int totalMOAmount = totalMaterialAmount + totalOtherExpAmt;
                            timeCardLineRow.setAttribute("TotalAmount", totalMOAmount);
                            if (poAmountRemaining.compareTo(totalMOAmount) == 1 ||
                                poAmountRemaining.compareTo(totalMOAmount) == 0) {
                                oracle.jbo.domain.Number FinalWoAmount =
                                    (oracle.jbo.domain.Number) poAmountRemaining.minus(totalMOAmount);
                                System.out.println("FinalWoAmount..." + FinalWoAmount);
                                poHeaderRow.setAttribute("AmountLimit", FinalWoAmount);
                                getBndPOAmount().setValue(FinalWoAmount);
                                statusFlag = true;
                            } else {
                                JSFUtils.addFacesErrorMessage("Insufficient Remaining Amount");
                            }
                        }
                        System.out.println("statusFlag..." + statusFlag);
                        if (statusFlag == true) {
                            timeCardLineRow.setAttribute("Status", "SUBMITTED");
                            timeCardLineRow.setAttribute("SelectedFlag", "N");
                        }

                        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndTotalAmount());
                        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndPOAmount());

                    } else if (doSubmit == false) {
                        JSFUtils.addFacesErrorMessage("Please add Labour/Material row for the selected TimeCardLineId");
                    }
                } catch (NullPointerException e) {
                    JSFUtils.addFacesErrorMessage("PO Amount is Null");
                    System.out.print("NullPointerException Caught");
                }
            }
            timeCardLineRow = timeCardLineRSI.next();
        }
        if (statusFlag == true) {
            System.out.println("Commited...");
            ADFUtils.findOperation("Commit").execute();
        }

    }

    public void saveTimeCards(ActionEvent actionEvent) {
        RowSetIterator timeCardLineRSI = ADFUtils.findIterator("TimeCardLineIterator").getRowSetIterator();
        Row timeCardLineRow = timeCardLineRSI.first();
        while (timeCardLineRow != null) {
            System.out.println("inside save method");
            String status = (String) timeCardLineRow.getAttribute("Status");
            if (!status.equalsIgnoreCase("IMPORTED") && !status.equalsIgnoreCase("APPROVED") &&
                !status.equalsIgnoreCase("SUBMITTED")) {
                System.out.println("inside save if loop");
                timeCardLineRow.setAttribute("Status", "DRAFT");
                timeCardLineRow.setAttribute("SelectedFlag", "N");
            }
            timeCardLineRow = timeCardLineRSI.next();
        }
        //Add code to send email
        ADFUtils.findOperation("Commit").execute();
    }

    public void approveTimeCardLines(ActionEvent actionEvent) {
        RowSetIterator timeCardLineRSI = ADFUtils.findIterator("TimeCardLineIterator").getRowSetIterator();
        Row timeCardLineRow = timeCardLineRSI.first();
        List<oracle.jbo.domain.Number> lineIdList = new ArrayList<oracle.jbo.domain.Number>();
        while (timeCardLineRow != null) {
            String status = (String) timeCardLineRow.getAttribute("Status");
            String selectedFlag = (String) timeCardLineRow.getAttribute("SelectedFlag");
            if ((status.equalsIgnoreCase("SUBMITTED")) && selectedFlag != null && selectedFlag.equalsIgnoreCase("Y")) {
                timeCardLineRow.setAttribute("Status", "APPROVED");
                timeCardLineRow.setAttribute("SelectedFlag", "N");
                oracle.jbo.domain.Number timeCardLineId =
                    (oracle.jbo.domain.Number) timeCardLineRow.getAttribute("TimeCardLineId");
                lineIdList.add(timeCardLineId);
            }
            timeCardLineRow = timeCardLineRSI.next();
        }
        //Add code to send email
        ADFUtils.findOperation("Commit").execute();
    }

    public void rejectTimeCardLines(ActionEvent actionEvent) {
        RowSetIterator timeCardLineRSI = ADFUtils.findIterator("TimeCardLineIterator").getRowSetIterator();
        Row timeCardLineRow = timeCardLineRSI.first();
        List<oracle.jbo.domain.Number> lineIdList = new ArrayList<oracle.jbo.domain.Number>();
        while (timeCardLineRow != null) {
            String status = (String) timeCardLineRow.getAttribute("Status");
            String selectedFlag = (String) timeCardLineRow.getAttribute("SelectedFlag");
            if (status.equalsIgnoreCase("SUBMITTED") && selectedFlag != null && selectedFlag.equalsIgnoreCase("Y")) {
                timeCardLineRow.setAttribute("Status", "REJECTED");
                timeCardLineRow.setAttribute("SelectedFlag", "N");
                oracle.jbo.domain.Number timeCardLineId =
                    (oracle.jbo.domain.Number) timeCardLineRow.getAttribute("TimeCardLineId");
                lineIdList.add(timeCardLineId);

                oracle.jbo.domain.Number TotalAmount =
                    (oracle.jbo.domain.Number) timeCardLineRow.getAttribute("TotalAmount");
                BindingContext ctx = BindingContext.getCurrent();
                DCBindingContainer bc = (DCBindingContainer) ctx.getCurrentBindingsEntry();
                DCIteratorBinding iterator = bc.findIteratorBinding("POHeaderViewIterator");
                Row poHeaderRow = iterator.getCurrentRow();
                oracle.jbo.domain.Number poAmountRemaining =
                    (oracle.jbo.domain.Number) poHeaderRow.getAttribute("AmountLimit");
                poHeaderRow.setAttribute("PoAmountRemaining",
                                         (oracle.jbo.domain.Number) poAmountRemaining.add(TotalAmount));
            }
            timeCardLineRow = timeCardLineRSI.next();
        }
        //Add code to send email
        ADFUtils.findOperation("Commit").execute();
    }

    public void applyUserRestrictions() {
        String userRole = (String) JSFUtils.getFromSession("role");
        oracle.jbo.domain.Number partyId = (oracle.jbo.domain.Number) JSFUtils.getFromSession("partyId");

        oracle.jbo.domain.Number employeeId = (oracle.jbo.domain.Number) JSFUtils.getFromSession("employeeId");

        // if (userRole.equalsIgnoreCase("SUPPLIER")) {
        OperationBinding executeStandardPoLOV = ADFUtils.findOperation("ExecuteStandardPoLOV");

        OperationBinding executeTimeCardSearch = ADFUtils.findOperation("ExecuteTimeCardSearch");
        // Changes made in Dec17
        executeStandardPoLOV.getParamsMap().put("bBuyerId", employeeId);
        executeTimeCardSearch.getParamsMap().put("bBuyerId", employeeId);
        executeStandardPoLOV.execute();
        executeTimeCardSearch.execute();
        //  }
    }

    public String navigateToView() {
        // Add event code here...
        FacesContext context = FacesContext.getCurrentInstance();
        DCBindingContainer container = getBindingContainer();

        bndTimeCardId.getClientId(context);

        String timeCardIdVal = String.valueOf(bndTimeCardId.getAttributes().get("timeCardIdVal"));
        DCIteratorBinding sdtLogIte = container.findIteratorBinding("TimeCardHeaderIterator");
        ViewObjectImpl sdtLogVOImpl = (ViewObjectImpl) sdtLogIte.getViewObject();

        ViewCriteria sdtLogCriteria = sdtLogVOImpl.getViewCriteria("TimeCardHeaderIdViewCriteria");
        sdtLogVOImpl.setNamedWhereClauseParam("bTCHId", timeCardIdVal);

        sdtLogVOImpl.applyViewCriteria(sdtLogCriteria);
        sdtLogVOImpl.executeQuery();
        return "edit";
    }


    private DCBindingContainer getBindingContainer() {
        BindingContext context = BindingContext.getCurrent();
        DCBindingContainer container = (DCBindingContainer) context.getCurrentBindingsEntry();
        return container;

    }

    public void setBndTimeCardId(RichCommandLink bndTimeCardId) {
        this.bndTimeCardId = bndTimeCardId;
    }

    public RichCommandLink getBndTimeCardId() {
        return bndTimeCardId;
    }

    public void deleteTimeCardLineId(ActionEvent actionEvent) {
        // Add event code here...

        RowSetIterator timeCardLineRSI = ADFUtils.findIterator("TimeCardLineIterator").getRowSetIterator();
        Row timeCardLineRow = timeCardLineRSI.last();
        while (timeCardLineRow != null) {
            String status = (String) timeCardLineRow.getAttribute("Status");
            String selectedFlag = (String) timeCardLineRow.getAttribute("SelectedFlag");
            if (!status.equalsIgnoreCase("IMPORTED") && !status.equalsIgnoreCase("APPROVED") && selectedFlag != null &&
                selectedFlag.equalsIgnoreCase("Y"))

            {


                FacesContext facesContext = FacesContext.getCurrentInstance();
                ELContext elContext = facesContext.getELContext();
                ExpressionFactory expressionFactory = facesContext.getApplication().getExpressionFactory();
                MethodExpression exp =
                    expressionFactory.createMethodExpression(elContext, "#{bindings.DeleteTimeCardLine.execute}",
                                                             (Class) Object.class, new Class[0]);
                exp.invoke(elContext, new Object[0]);
            } else if (status.equalsIgnoreCase("ENTERED")) {
                FacesContext facesContext = FacesContext.getCurrentInstance();
                ELContext elContext = facesContext.getELContext();
                ExpressionFactory expressionFactory = facesContext.getApplication().getExpressionFactory();
                MethodExpression exp =
                    expressionFactory.createMethodExpression(elContext, "#{bindings.DeleteTimeCardLine.execute}",
                                                             (Class) Object.class, new Class[0]);
                exp.invoke(elContext, new Object[0]);

            }
            timeCardLineRow = timeCardLineRSI.next();
        }
        //Add code to send email
        ADFUtils.findOperation("Commit").execute();
    }


    public void setBndTotalAmount(RichOutputText bndTotalAmount) {
        this.bndTotalAmount = bndTotalAmount;
    }

    public RichOutputText getBndTotalAmount() {
        return bndTotalAmount;
    }

    public void setBndLabourAmount(RichOutputText bndLabourAmount) {
        this.bndLabourAmount = bndLabourAmount;
    }

    public RichOutputText getBndLabourAmount() {
        return bndLabourAmount;
    }

    public void setBndMaterialAmount(RichOutputText bndMaterialAmount) {
        this.bndMaterialAmount = bndMaterialAmount;
    }

    public RichOutputText getBndMaterialAmount() {
        return bndMaterialAmount;
    }

    public void getPOHeaderId(ValueChangeEvent valueChangeEvent) {
        // Add event code here...

        String poIdValue = valueChangeEvent.getNewValue().toString();
        System.out.println("poIdValue..." + poIdValue);
        this.setPoId(valueChangeEvent.getNewValue().toString());

        BindingContext ctx = BindingContext.getCurrent();
        DCBindingContainer bc = (DCBindingContainer) ctx.getCurrentBindingsEntry();
        DCIteratorBinding iterator = bc.findIteratorBinding("StandardPOLOVIterator");
        ViewObjectImpl vo = (ViewObjectImpl) iterator.getViewObject();
        ViewCriteria vc = vo.getViewCriteria("StandardPOLOVCriteria");
        vo.applyViewCriteria(vc);
        vo.setNamedWhereClauseParam("bPoHId", poIdValue);
        vo.executeQuery();
        Row buyerRow = iterator.getCurrentRow();
        oracle.jbo.domain.Number buyerId = (oracle.jbo.domain.Number) buyerRow.getAttribute("BuyerId");
        System.out.println("buyerId..." + buyerId);


        DCIteratorBinding iterator1 = bc.findIteratorBinding("EmployeeViewIterator");
        ViewObjectImpl vo1 = (ViewObjectImpl) iterator1.getViewObject();
        ViewCriteria vc1 = vo1.getViewCriteria("EmployeeViewCriteria");
        vo1.applyViewCriteria(vc1);
        vo1.setNamedWhereClauseParam("bEmpId", buyerId);
        vo1.executeQuery();
        Row approverRow = iterator1.getCurrentRow();
        String approverName = (String) approverRow.getAttribute("FullName");


        //                iterator.getViewObject().setNamedWhereClauseParam("bPONum",poIdValue);
        //                iterator.executeQuery();
        //                Row approverRow = iterator.getCurrentRow();
        //                String approverName = (String) approverRow.getAttribute("FullName");
        //                System.out.println("approverName..."+approverName);
        getBndApprover().setValue(approverName);
        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndApprover());


        DCIteratorBinding iterator2 = bc.findIteratorBinding("POHeaderViewIterator");
        ViewObjectImpl vo2 = (ViewObjectImpl) iterator2.getViewObject();
        ViewCriteria vc2 = vo2.getViewCriteria("POHeaderViewCriteria");
        vo2.applyViewCriteria(vc2);
        vo2.setNamedWhereClauseParam("bPoHId", poIdValue);
        vo2.executeQuery();
        Row poHeaderRow = iterator2.getCurrentRow();
        oracle.jbo.domain.Number poAmountRemaining = (oracle.jbo.domain.Number) poHeaderRow.getAttribute("AmountLimit");
        System.out.println("poAmountRemaining in po header listener..." + poAmountRemaining);
        getBndPOAmount().setValue(poAmountRemaining);
        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndPOAmount());
    }

    public void setPoId(String poId) {
        this.poId = poId;
    }

    public String getPoId() {
        return poId;
    }

    public void setBndApprover(RichOutputText bndApprover) {
        this.bndApprover = bndApprover;
    }

    public RichOutputText getBndApprover() {
        return bndApprover;
    }

    public void setBndPOAmount(RichOutputText bndPOAmount) {
        this.bndPOAmount = bndPOAmount;
    }

    public RichOutputText getBndPOAmount() {
        return bndPOAmount;
    }

    public void getRateCardId(ValueChangeEvent valueChangeEvent) {
        // Add event code here...
        System.out.println("getBndRateCardId..." + getBndRateCardId().getValue());
        valueChangeEvent.getComponent().processUpdates(FacesContext.getCurrentInstance());
        this.setRateCardId(valueChangeEvent.getNewValue().toString());

        Map map = ((UIComponent) valueChangeEvent.getSource()).getAttributes();
        String getRateCardId = (String) map.get("rowIndexVal");
        System.out.println("getRateCardId..." + getRateCardId);
        // String str = " Hello I'm your String";
        String[] splitStr = getRateCardId.split("\\.");
        String rNumber = splitStr[0];
        String rLineNumber = splitStr[1];
        System.out.println("Rate Card Number..." + rNumber);
        System.out.println("Rate Card Line Number..." + rLineNumber);

        BindingContext ctx2 = BindingContext.getCurrent();
        DCBindingContainer bc2 = (DCBindingContainer) ctx2.getCurrentBindingsEntry();
        DCIteratorBinding iterator2 = bc2.findIteratorBinding("RateCardHeaderToLineView1Iterator");
        ViewObjectImpl vo2 = (ViewObjectImpl) iterator2.getViewObject();
        ViewCriteria vc2 = vo2.getViewCriteria("RateCardHeaderToLineViewCriteria");
        vo2.applyViewCriteria(vc2);
        vo2.setNamedWhereClauseParam("bRateCardNumber", rNumber);
        vo2.setNamedWhereClauseParam("bRateCardLineNumber", rLineNumber);
        vo2.executeQuery();
        Row lineRow2 = iterator2.getCurrentRow();

        oracle.jbo.domain.Number RateCardLineId = (oracle.jbo.domain.Number) lineRow2.getAttribute("RateCardLineId");
        System.out.println("RateCardLineId..." + RateCardLineId);

        BindingContext ctx = BindingContext.getCurrent();
        DCBindingContainer bc = (DCBindingContainer) ctx.getCurrentBindingsEntry();
        DCIteratorBinding iterator1 = bc.findIteratorBinding("RateCardLineLOV1Iterator");
        ViewObjectImpl vo1 = (ViewObjectImpl) iterator1.getViewObject();
        vo1.setNamedWhereClauseParam("bRateCardLineId", RateCardLineId);
        vo1.executeQuery();
        Row lineRow = iterator1.getCurrentRow();

        String RoleType = (String) lineRow.getAttribute("RoleType");
        System.out.println("RoleType..." + RoleType);
        //getBndRoleType1().setValue(RoleType);
        //
        String Role = (String) lineRow.getAttribute("Role");
        System.out.println("Role..." + Role);
        //getBndRole1().setValue(Role);
        //
        String Region = (String) lineRow.getAttribute("Region");
        System.out.println("Region..." + Region);
        //getBndRegion1().setValue(Region);
        //
        String WorkType = (String) lineRow.getAttribute("WorkType");
        System.out.println("WorkType..." + WorkType);
        //getBndWorkType1().setValue(WorkType);
        
        
        BindingContext ctx3 = BindingContext.getCurrent();
        DCBindingContainer bc3 = (DCBindingContainer) ctx3.getCurrentBindingsEntry();
        DCIteratorBinding iterator3 = bc3.findIteratorBinding("LaborChargesIterator");
        Row currRow = iterator3.getCurrentRow();
        currRow.setAttribute("RoleType", RoleType);
        currRow.setAttribute("Role", Role);
        currRow.setAttribute("Region", Region);
        currRow.setAttribute("WorkType", WorkType);
        //        //        String RateType = (String) approverRow.getAttribute("RateType");
        //        //        System.out.println("RateType..."+RateType);
        //        //        getBndRateType().setValue(RateType);
        //
        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndRoleType1());
        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndRole1());
        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndRegion1());
        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndWorkType1());
        //        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndRateType());


    }
    
    public void createLineNumber(ActionEvent actionEvent) {
        // Add event code here...

        DCBindingContainer bc = (DCBindingContainer) BindingUtils.getBindingContext().getCurrentBindingsEntry();

        DCIteratorBinding iterator = bc.findIteratorBinding("TimeCardLineIterator");
        ViewObjectImpl lineVo = (ViewObjectImpl) iterator.getViewObject();
        oracle.jbo.Row lineRow = (oracle.jbo.Row) lineVo.createRow();
        lineRow.setNewRowState(oracle.jbo.Row.STATUS_INITIALIZED);
        lineNumCounter =(int)iterator.getEstimatedRowCount();
        lineNumCounter=lineNumCounter + 1;
        oracle.jbo.domain.Number lineNum = new oracle.jbo.domain.Number(lineNumCounter);
        System.out.println("lineNum..."+lineNum);
        lineRow.setAttribute("TimeCardLineNumber", lineNum);
        lineVo.last();
        lineVo.next();
        lineVo.insertRow(lineRow);

        getBndLineNumber().setValue(lineNum);
        AdfFacesContext.getCurrentInstance().addPartialTarget(getBndLineNumber());
        
    }

    public void setRateCardId(String rateCardId) {
        this.rateCardId = rateCardId;
    }

    public String getRateCardId() {
        return rateCardId;
    }

    public void setBndRoleType1(RichSelectOneChoice bndRoleType1) {
        this.bndRoleType1 = bndRoleType1;
    }

    public RichSelectOneChoice getBndRoleType1() {
        return bndRoleType1;
    }

    public void setBndRateCardId(RichSelectOneChoice bndRateCardId) {
        this.bndRateCardId = bndRateCardId;
    }

    public RichSelectOneChoice getBndRateCardId() {
        return bndRateCardId;
    }

    public void setBndRole1(RichSelectOneChoice bndRole1) {
        this.bndRole1 = bndRole1;
    }

    public RichSelectOneChoice getBndRole1() {
        return bndRole1;
    }

    public void setBndRegion1(RichSelectOneChoice bndRegion1) {
        this.bndRegion1 = bndRegion1;
    }

    public RichSelectOneChoice getBndRegion1() {
        return bndRegion1;
    }

    public void setBndWorkType1(RichSelectOneChoice bndWorkType1) {
        this.bndWorkType1 = bndWorkType1;
    }

    public RichSelectOneChoice getBndWorkType1() {
        return bndWorkType1;
    }

    public void setBndLineNumber(RichInputText bndLineNumber) {
        this.bndLineNumber = bndLineNumber;
    }

    public RichInputText getBndLineNumber() {
        return bndLineNumber;
    }
}

