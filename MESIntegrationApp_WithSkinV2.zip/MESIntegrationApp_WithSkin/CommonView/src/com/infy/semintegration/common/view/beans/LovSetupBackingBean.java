package com.infy.semintegration.common.view.beans;

import com.infy.semintegration.common.view.utils.ADFUtils;
import com.infy.semintegration.common.view.utils.JSFUtils;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.jbo.ViewCriteria;
import oracle.jbo.server.ViewObjectImpl;

public class LovSetupBackingBean {
    public LovSetupBackingBean() {
        super();
    }
    public void applyUserRestrictions() {
          String userRole = (String) JSFUtils.getFromSession("role");
          oracle.jbo.domain.Number partyId = (oracle.jbo.domain.Number) JSFUtils.getFromSession("partyId");

          oracle.jbo.domain.Number employeeId = (oracle.jbo.domain.Number) JSFUtils.getFromSession("employeeId");


      }

    public void navigateToDetails(ActionEvent actionEvent) {
        oracle.jbo.Row setupDefRow = ADFUtils.findIterator("LovSetupDefinitionView1Iterator").getCurrentRow();
                 System.out.println("SetupCode:"+setupDefRow.getAttribute("SetupCode"));
        oracle.jbo.domain.Number setupCode=(oracle.jbo.domain.Number)setupDefRow.getAttribute("SetupCode");
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("passSetupCode", setupCode);
        
        String setupName=(String)setupDefRow.getAttribute("SetupName");
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("passSetupName", setupName);
        
        BindingContext ctx1 = BindingContext.getCurrent();      
        DCBindingContainer bc1 = (DCBindingContainer) ctx1.getCurrentBindingsEntry();
        DCIteratorBinding iterator = bc1.findIteratorBinding("SetupDetailsView1Iterator");
        ViewObjectImpl vo =(ViewObjectImpl)iterator.getViewObject();
        ViewCriteria vc =vo.getViewCriteria("SetupDetailsViewCriteria");
        vo.applyViewCriteria(vc);
        vo.setNamedWhereClauseParam("bindSetupCode",null);
        vo.executeQuery();
        vo.setNamedWhereClauseParam("bindSetupCode",setupCode);
        vo.executeQuery();
        
    }
}
