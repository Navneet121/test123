package com.infy.semintegration.common.view.beans;

import com.infy.semintegration.common.view.utils.ADFUtils;
import com.infy.semintegration.common.view.utils.JSFUtils;

//import com.sun.faces.config.JSFVersionTracker;
//
//import com.sun.faces.renderkit.JsfJsResourcePhaseListener;

import java.io.IOException;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import javax.security.auth.Subject;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import oracle.adf.share.ADFContext;
import oracle.adf.share.security.AuthenticationService;
import oracle.adf.share.security.authentication.AuthenticationServiceUtil;


import oracle.binding.OperationBinding;

import oracle.jbo.Row;

import oracle.jbo.RowIterator;
import oracle.jbo.domain.Number;

import weblogic.security.URLCallbackHandler;
import weblogic.security.services.Authentication;

import weblogic.servlet.security.ServletAuthentication;

public class Login {
    public Login() {
    }

    private String username;
    private String password;


    public void login(ActionEvent ae) {
        FacesContext ctx = FacesContext.getCurrentInstance();

        if (username == null || password == null) {
            showError("Invalid credentials",
                      "An incorrect username or password was specified.",
                      null);
        } else {
            ExternalContext ectx = ctx.getExternalContext();
            HttpServletRequest request = (HttpServletRequest)ectx.getRequest();
            Subject mySubject;

            try {
                OperationBinding op = ADFUtils.findOperation("FetchUserDetails");
                op.getParamsMap().put("bUserName",username);
                op.execute();
                Row userRow =
                    ADFUtils.findIterator("UsersViewIterator").getCurrentRow();
                if (userRow != null) {
                    Number userId = (Number)userRow.getAttribute("UserId");
                    String role = (String)userRow.getAttribute("Role");
                    Number partyId = (Number)userRow.getAttribute("PartyId");
                    Number employeeId = (Number)userRow.getAttribute("EmployeeId");
                    String email = (String)userRow.getAttribute("UserName");
                    mySubject =
                            Authentication.login(new URLCallbackHandler(username,
                                                                        password.getBytes()));
                    ServletAuthentication.runAs(mySubject, request);
                    ServletAuthentication.generateNewSessionID(request);
                    redirect(ectx.getRequestContextPath() + "/faces/Main");


                    JSFUtils.storeOnSession("userId", userId);
                    JSFUtils.storeOnSession("role", role);
                    JSFUtils.storeOnSession("partyId", partyId);
                    JSFUtils.storeOnSession("employeeId", employeeId);
                    JSFUtils.storeOnSession("email", email);
                    
                } else {
                    JSFUtils.addFacesMessage(FacesMessage.SEVERITY_ERROR,
                                             "An incorrect username or password was specified.");
                }

            } catch (Exception e) {
                e.printStackTrace();
                JSFUtils.addFacesMessage(FacesMessage.SEVERITY_ERROR,
                                         "An incorrect username or password was specified.");
            } finally {
                username = null;
                password = null;
            }
        }
    }

    public void logout(ActionEvent ae) {
        try {
            AuthenticationService authenticationService =
                AuthenticationServiceUtil.getAuthenticationService();
            authenticationService.logout("faces/Login", null);
        } catch (Exception e) {
            showError("AuthenticationServiceException",
                      "An error occurred during logout.Please consult logs for more information.",
                      e);
        } finally {
        }
    }

    private void showError(String errType, String message, Exception e) {
        JSFUtils.addFacesErrorMessage(errType, message);
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    private void redirect(String forwardUrl) {
        FacesContext ctx = FacesContext.getCurrentInstance();
        ExternalContext ectx = ctx.getExternalContext();
        try {
            ectx.redirect(forwardUrl);
        } catch (IOException ie) {
            showError("IOException",
                      "An error occurred during redirecting. Please consult logs for more information.",
                      ie);
        }
    }
}
