package com.infy.semintegration.common.view.beans;

import com.infy.semintegration.common.view.utils.JSFUtils;

import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import oracle.adf.controller.TaskFlowId;
import oracle.adf.share.ADFContext;
import oracle.adf.view.rich.component.rich.nav.RichCommandButton;

public class GlobalTemplatesBean {
    public void handleGoHome(ActionEvent ae) {
        FacesContext fctx = FacesContext.getCurrentInstance();
        UIViewRoot vr = fctx.getViewRoot();
        if (vr.getViewId().equals("/FilmStrip")){
            RichCommandButton actionTrigger = (RichCommandButton)vr.findComponent("pt1:pt_navigationTrigger");
            ActionEvent actionEvent = new ActionEvent(actionTrigger);
            actionEvent.queue();
        }//check if navigation required
    }//handleGoHome
    
    public boolean isHeadless(){
        String headless = (String)ADFContext.getCurrent().getSessionScope().get("headless");
        if (headless!=null && headless.equals("yes"))
            return true;
        else 
            return false;
    }//isHeadless
    
    public TaskFlowId getDynamicTaskFlowId() {
        TaskFlowId timeCardTFId = new TaskFlowId("/com/infy/semintegration/common/taskflows/TimeCardTaskFlow.xml", "TimeCardTaskFlow");

        TaskFlowId rateCardTFId = new TaskFlowId("/com/infy/semintegration/common/taskflows/RateCardTaskFlow.xml", "RateCardTaskFlow");
        TaskFlowId lovSetupId = new TaskFlowId("/com/infy/semintegration/common/taskflows/LovSetupTaskFlow.xml", "LovSetupTaskFlow");
        String currentModule=(String)JSFUtils.getFromSession("currentModule");
        System.out.println("currentModule..."+currentModule);
            if(currentModule!=null && currentModule.equalsIgnoreCase("TIME_CARD")){
                        return timeCardTFId;
                    }else if(currentModule!=null && currentModule.equalsIgnoreCase("LOV_SETUP"))
                    {
                        return lovSetupId;
                    }
                    else {
                        return  rateCardTFId;
                    } 
    }
}
