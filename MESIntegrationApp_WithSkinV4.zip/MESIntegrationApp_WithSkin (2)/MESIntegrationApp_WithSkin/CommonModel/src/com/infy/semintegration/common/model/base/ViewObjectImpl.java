package com.infy.semintegration.common.model.base;


import oracle.jbo.server.ViewDefImpl;


public class ViewObjectImpl extends oracle.jbo.server.ViewObjectImpl {
    //private static CustomADFLogger LOGGER = CustomADFLogger.createADFLogger(ViewObjectImpl.class);
    int fetched = 0;

    public ViewObjectImpl(String string, ViewDefImpl viewDefImpl) {
        super(string, viewDefImpl);
    }

    public ViewObjectImpl() {
        super();
    }

    
}
